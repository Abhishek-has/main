package main

import (
	"fmt"
)

// entry point
func main() {
	fmt.Println("Hello Go World !")
}
